#include <iostream>
#include <cstdio>
#include <gl/gl.h>
#include <gl/glext.h>

int main(int argc, char *argv[])
{
    
    return 0;
}
